# -*- coding: utf-8 -*-
"""测试用例 txt 自检脚本（对应《测试用例编写规范.md》自检清单）。

用法:
    python check_case_file.py <用例文件.txt>

检查项:
    1. 叶子节点是否带违规前缀（验证/检查/测试/确认）
    2. 非叶子分类名是否 >= 4 个汉字
    3. Tab 层级是否连续（不允许跳级）
    4. 统计叶子用例数与各级节点数
"""
import re
import sys


def tabs(line):
    return len(line) - len(line.lstrip('\t'))


def main(path):
    lines = open(path, encoding='utf-8').read().splitlines()
    leaf_count = 0
    bad_prefix = []
    short_names = []
    level_jump = []
    counts = {}
    prev = 0
    for i, l in enumerate(lines):
        if not l.strip():
            continue
        t = tabs(l)
        counts[t] = counts.get(t, 0) + 1
        if t > prev + 1:
            level_jump.append((i + 1, l.strip()))
        prev = t
        nxt = lines[i + 1] if i + 1 < len(lines) else ''
        nt = tabs(nxt) if nxt.strip() else 0
        is_leaf = not nxt.strip() or nt <= t
        name = l.strip()
        if is_leaf:
            leaf_count += 1
            if re.match(r'^(验证|检查|测试|确认)', name):
                bad_prefix.append((i + 1, name))
        elif len(name) < 4:
            short_names.append((i + 1, name))

    print('叶子用例数:', leaf_count)
    print('各级节点数:', dict(sorted(counts.items())))
    ok = True
    if bad_prefix:
        ok = False
        print('违规前缀（验证/检查/测试/确认开头）:')
        for ln, n in bad_prefix:
            print('  行%d: %s' % (ln, n))
    if short_names:
        ok = False
        print('分类名不足4字:')
        for ln, n in short_names:
            print('  行%d: %s' % (ln, n))
    if level_jump:
        ok = False
        print('层级跳级:')
        for ln, n in level_jump:
            print('  行%d: %s' % (ln, n))
    print('自检结果:', 'PASS' if ok else 'FAIL')
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('用法: python check_case_file.py <用例文件.txt>')
        sys.exit(2)
    main(sys.argv[1])
